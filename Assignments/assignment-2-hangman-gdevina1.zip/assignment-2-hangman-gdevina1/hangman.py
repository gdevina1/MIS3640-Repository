# Hangman game
#

# -----------------------------------
# Helper code
# You don't need to understand this helper code,
# but you will have to know how to use the functions
# (so be sure to read the docstrings!)

import random

WORDLIST_FILENAME = "words.txt"


def loadWords():
    """
    Returns a list of valid words. Words are strings of lowercase letters.

    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print("Loading word list from file...")
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r')
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print("  ", len(wordlist), "words loaded.")
    return wordlist


def chooseWord(wordlist):
    """
    wordlist (list): list of words (strings)

    Returns a word from wordlist at random
    """
    return random.choice(wordlist)

# end of helper code
# -----------------------------------

# Load the list of words into the variable wordlist
# so that it can be accessed from anywhere in the program
wordlist = loadWords()


def isWordGuessed(secretWord, lettersGuessed):
    '''
    secretWord: string, the word the user is guessing
    lettersGuessed: list, what letters have been guessed so far
    returns: boolean, True if all the letters of secretWord are in lettersGuessed;
      False otherwise
    '''
    for letter in secretWord:          #loop continues for every letter in the secret word
        if letter in lettersGuessed:   #if the value/letter is in the list letterGuessed, then pass the if function
            continue
        return False                   #if the value/letter is not in the list lettersGuessed, then return FALSE
    return True                        #if all letters in secretWord are in lettersGuessed, return TRUE

# When you've completed your function isWordGuessed, uncomment these three lines
# and run this file to test!

# secretWord = 'apple'
# lettersGuessed = ['e', 'i', 'k', 'p', 'r', 's']
# print(isWordGuessed(secretWord, lettersGuessed))

# Expected output:
# False


def getGuessedWord(secretWord, lettersGuessed):
    '''
    secretWord: string, the word the user is guessing
    lettersGuessed: list, what letters have been guessed so far
    returns: string, comprised of letters and underscores that represents
      what letters in secretWord have been guessed so far.
    '''
    notGuessed = "_" * len(secretWord)                                    #a string of underscores times the number of letters in the secret word
    for i in range(len(secretWord)):                                      #loop continues until it goes through every letter in the secret word
      if secretWord[i] in lettersGuessed:                                 #if a letter in the secret word is also in letterGuessed,
        notGuessed = notGuessed[:i] + secretWord[i] + notGuessed[i+1:]    #then the string will replace _ with the letters that are in letterGuessed in the order that it appears in secretWord
    return notGuessed                                                     


# # When you've completed your function getGuessedWord, uncomment these three lines
# # and run this file to test!

# secretWord = 'apple'
# lettersGuessed = ['e', 'i', 'k', 'p', 'r', 's']
# print(getGuessedWord(secretWord, lettersGuessed))

# # Expected output:
# # '_ pp_ e'


def getAvailableLetters(lettersGuessed):
    '''
    lettersGuessed: list, what letters have been guessed so far
    returns: string, comprised of letters that represents what letters have not
      yet been guessed.
    '''
    # Hint: You might consider using string.ascii_lowercase, which
    # is a string comprised of all lowercase letters.
    
    # FILL IN YOUR CODE HERE...
    import string
    alphabet = string.ascii_lowercase               #create a string of lowercase alphabets
    for letter in lettersGuessed:                   #loop continues for every letter in the lettersGuessed list
      if letter in alphabet:                        #if a letter in letterGuessed is found in the string alphabet
        alphabet = alphabet.replace(letter, "")     #then the function replaces the letter in the string with a blank, or in other words, delete the letter from the string
    return alphabet                                 #returns alphabet string after taking out all the letters in lettersGuessed


# # When you've completed your function getAvailableLetters, uncomment these two lines
# # and run this file to test!

# lettersGuessed = ['e', 'i', 'k', 'p', 'r', 's']
# print(getAvailableLetters(lettersGuessed))

# # Expected output:
# # abcdfghjlmnoqtuvwxyz


def hangman(secretWord):
    '''
    secretWord: string, the secret word to guess.

    Starts up an interactive game of Hangman.

    * At the start of the game, let the user know how many 
      letters the secretWord contains.

    * Ask the user to supply one guess (i.e. letter) per round.

    * The user should receive feedback immediately after each guess 
      about whether their guess appears in the computers word.

    * After each round, you should also display to the user the 
      partially guessed word so far, as well as letters that the 
      user has not yet guessed.

    Follows the other limitations detailed in the problem write-up.
    '''

    print("")
    print ("--------------------H A N G M A N-------------------------")
    print("")
    print ("Let's start! Guess the secret word that has %d letters.." % len(secretWord)) #lets player know how many letters there are in the secret word
    print("")
    remainingGuesses = 8                                                                 #player only gets 8 guests
    remainingAlphabets = "a b c d e f g h i j k l m n o p q r s t u v w x y z"           #string of lowercase alphabets(since getAvailableLetters comes without spaces)
    remainingAlphabetsList = remainingAlphabets.split()                                  #turns string into list                         
    lettersGuessed = []                                                                  #creates list of letters guessed
    while remainingGuesses > 0 and isWordGuessed(secretWord, lettersGuessed) == False:   #loops as long as there are more than 0 guesses remaining and word has not been correctly guessed
      print("You have %d guesses remaining." % remainingGuesses)                         #lets player know how many guesses remain
      print("")
      print("Alphabet guesses remaining: ")
      print(remainingAlphabetsList)                                                      #print list of alphabets not yet guessed
      print("")
      guess = input("Guess a letter:")                                                   #asks player to input a letter
      if guess not in remainingAlphabetsList:                                            #if input is not in remainingAlphabetsList, show error message
        print("")
        print("--------------------------------------------------")
        print("That's a repeat guess. Try a different letter: ")
        print("--------------------------------------------------")
        print("")
        print(getGuessedWord(secretWord, lettersGuessed))                                #print letters guessed correctly and letters not yet guessed as underscores
        print("")
      else:                                                                              #if input is in remainingAlphabetsList
        lettersGuessed.append(guess)                                                     #add the input letter to the lettersGuessed list
        remainingAlphabetsList.remove(guess)                                             #remove it from the remainingAlphabetsList
        if guess in secretWord:                                                          #if the input is a correct guess/can be found in the secret word, show congratulatory message
          print("")
          print("--------------------------------------------------")
          print("You guessed correctly! Keep going!")
          print("--------------------------------------------------")
          print("")
          print(getGuessedWord(secretWord, lettersGuessed))                              #show progress of what's been guessed and what hasn't                  
          print("")
        else:                                                                            #if input is an incorrect guess/can't be found in the secret word, let user know
          print("")
          print("--------------------------------------------------")
          print("That letter is not in the secret word. Try again: ")
          print("--------------------------------------------------")
          print("")
          remainingGuesses = remainingGuesses - 1                                        #decreases remaining guess count by 1 if guess is incorrect
          print(getGuessedWord(secretWord, lettersGuessed))                              #show profress of what's been guessed and what hasn't
          print("")
    if remainingGuesses == 0:                                                            #stop the game if there are 0 guesses remaining, which means the player loses
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("Y O U  L O S E")
      print("The secret word was:", secretWord)                                          #reveals the secret word to the player
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("--------------------------------------------------")
    else:                                                                                #stops the game if remainingGuesses > 0 and all letters in secret word are guessed
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("-----------------Y O U  W I N !-------------------")                        #lets player know they've won
      print("----------------------GGEZ------------------------")
      print("--------------------------------------------------")
      print("--------------------------------------------------")
      print("--------------------------------------------------")


# # When you've completed your hangman function, uncomment these two lines
# # and run this file to test! (hint: you might want to pick your own
# # secretWord while you're testing)

secretWord = chooseWord(wordlist).lower()
hangman(secretWord)
