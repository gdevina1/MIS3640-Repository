print('hello, world!')

print("Hey", "Jude,", 'don\'t make it bad')

print("46 + 37 + 38 =", 46+37+38)


#name = input("Please enter your name: ")
#print("hello,", name)


message = 'I learned something cool!~'

n = 100
pi = 3.14

first_name = 'John'
last_name = 'Lennon'
print(first_name + last_name)

print('Naah, na na nanana naah, nanana naah, hey Jude. ' * 10)


print('Hello, %s' % first_name)

print('Today is %2d-%02d.' % (9, 5))



minute = 45 # current time

# compute the percentage of the hour that has elapsed
percentage = (minute * 100) / 60