import my_math

print("this is my_game.")

n = int(input())
print(my_math.square(n))
