age = int(input("Please enter your age: "))

if age > 21:
    print('Yes, you can.')
else:
    print('No, you are not allowed.')




