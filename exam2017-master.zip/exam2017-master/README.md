# Exam 2017Fall

## Exam Instruction

* The exam will be available starting from Tuesday 11/14 at 1:15 pm.
* The exam will close on Wednesday 11/15 at 1:15 pm.
* You need to submit two .py files via Blackboard - Session 21.
* You can use all class materials. You can use the internet to look up documentation and to clarify your knowledge of certain topics.
* You can NOT request or obtain help from others in any format, including but not limited to posting an ask-for-help message in any website, talking to others for help, emailing exam to others. Any one who looks for help from others would get zero for the exam.
* Check Slack periodically in case Professor Li might make some clarification on questions.
